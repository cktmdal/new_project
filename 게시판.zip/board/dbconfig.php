<?php
    $db = new mysqli('localhost', 'aaa', 'bbb', 'aaa');
/*두번째는 Db계정 세번째는 패스워드 네번째는 DB명*/ 
    if ($db->connect_error) {
        die('데이터베이스 연결에 문제가 있습니다.\n관리자에게 문의 바랍니다.');
    }

    $db->set_charset('utf8');
 ?>